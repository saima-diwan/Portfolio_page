import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import FeaturedWork from "@/components/featured-work"
import AboutCalligraphy from "@/components/about-calligraphy"
import HistoricalSection from "@/components/historical-section"
import ProjectsSection from "@/components/projects-section"
import ServicesSection from "@/components/services-section"
import QuoteSection from "@/components/quote-section"
import ContactSection from "@/components/contact-section"
import Footer from "@/components/footer"

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-[#f8f7f2]">
      <Header />
      <main>
        <HeroSection />
        <AboutCalligraphy />
        <FeaturedWork />
        <HistoricalSection />
        <ProjectsSection />
        <ServicesSection />
        <QuoteSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  )
}


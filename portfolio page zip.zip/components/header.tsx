import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Menu } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-[#f8f7f2]/80 backdrop-blur-sm">
      <div className="container flex h-16 items-center justify-between">
        <div className="font-serif text-xl font-bold text-[#1a3a3a]">Noor Designs</div>
        <nav className="hidden md:flex gap-6">
          <Link href="#about" className="text-sm font-medium text-[#1a3a3a] hover:text-[#8a6e4b] transition-colors">
            About
          </Link>
          <Link href="#projects" className="text-sm font-medium text-[#1a3a3a] hover:text-[#8a6e4b] transition-colors">
            Projects
          </Link>
          <Link href="#services" className="text-sm font-medium text-[#1a3a3a] hover:text-[#8a6e4b] transition-colors">
            Services
          </Link>
          <Link href="#contact" className="text-sm font-medium text-[#1a3a3a] hover:text-[#8a6e4b] transition-colors">
            Contact
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          <Button className="bg-[#1a3a3a] hover:bg-[#1a3a3a]/90 text-white" size="sm" asChild>
            <Link href="#contact">Get in touch</Link>
          </Button>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col gap-4 mt-8">
                <Link href="#about" className="text-lg font-medium hover:text-[#8a6e4b] transition-colors">
                  About
                </Link>
                <Link href="#projects" className="text-lg font-medium hover:text-[#8a6e4b] transition-colors">
                  Projects
                </Link>
                <Link href="#services" className="text-lg font-medium hover:text-[#8a6e4b] transition-colors">
                  Services
                </Link>
                <Link href="#contact" className="text-lg font-medium hover:text-[#8a6e4b] transition-colors">
                  Contact
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}


import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function HistoricalSection() {
  return (
    <section className="py-20 bg-[#f0ede3]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-[#1a3a3a]">The Art of Islamic Calligraphy</h2>
          <p className="text-[#1a3a3a]/70 max-w-2xl mx-auto mt-4">
            Exploring the rich heritage and artistic traditions that inspire our contemporary work
          </p>
          <div className="w-24 h-1 bg-[#8a6e4b] mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="relative aspect-square w-full max-w-md mx-auto lg:mx-0">
            <Image
              src="https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg"
              alt="Bifolium from the Nurse's Qur'an"
              fill
              className="object-contain rounded-lg shadow-lg"
            />
          </div>
          <div className="space-y-6">
            <h3 className="text-2xl font-serif font-bold text-[#1a3a3a]">Bifolium from the "Nurse's Qur'an"</h3>
            <p className="text-[#1a3a3a]/80">
              This magnificent bifolium dates from approximately 410 AH/1019-20 CE and represents the pinnacle of early
              Qur'anic calligraphy. The elegant script and meticulous attention to proportions demonstrate the sacred
              importance of calligraphy in Islamic tradition.
            </p>
            <p className="text-[#1a3a3a]/80">
              The careful balance of positive and negative space, the rhythm of the letterforms, and the harmonious
              composition all inform our contemporary approach to Islamic design.
            </p>
            <Button className="bg-[#8a6e4b] hover:bg-[#8a6e4b]/90 text-white" asChild>
              <Link href="#projects">See Our Inspired Works</Link>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 order-2 lg:order-1">
            <h3 className="text-2xl font-serif font-bold text-[#1a3a3a]">The "Blue Qur'an"</h3>
            <p className="text-[#1a3a3a]/80">
              The "Blue Qur'an" is one of the most extraordinary manuscripts in Islamic art history. Created between the
              late 9th and early 10th century, its deep indigo-dyed parchment with gold Kufic script represents the
              height of luxury and artistic achievement.
            </p>
            <p className="text-[#1a3a3a]/80">
              The stark contrast between the gold calligraphy and the rich blue background creates a visual impact that
              continues to inspire contemporary Islamic designers and calligraphers today.
            </p>
            <Button className="bg-[#8a6e4b] hover:bg-[#8a6e4b]/90 text-white" asChild>
              <Link href="#contact">Commission Custom Calligraphy</Link>
            </Button>
          </div>
          <div className="relative aspect-square w-full max-w-md mx-auto lg:mx-0 order-1 lg:order-2">
            <Image
              src="https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg"
              alt="Folio from the Blue Qur'an"
              fill
              className="object-contain rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  )
}


import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"

interface Testimonial {
  content: string
  author: string
  role: string
  avatar: string
}

export default function TestimonialsSection() {
  const testimonials: Testimonial[] = [
    {
      content:
        "Alex delivered our project on time and exceeded our expectations. The website is not only beautiful but also performs exceptionally well.",
      author: "Sarah Johnson",
      role: "CEO, TechStart",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      content:
        "Working with Alex was a pleasure. Their attention to detail and problem-solving skills made our complex project seem effortless.",
      author: "Michael Chen",
      role: "Product Manager, InnovateCo",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      content:
        "The dashboard Alex built for us has transformed how we analyze our data. It's intuitive, fast, and exactly what we needed.",
      author: "Emily Rodriguez",
      role: "Data Analyst, DataViz",
      avatar: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <section id="testimonials" className="py-20 bg-secondary/30">
      <div className="container">
        <div className="space-y-4 text-center mb-12">
          <h2 className="text-3xl font-bold">What Clients Say</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Don't just take my word for it. Here's what some of my clients have to say about working with me.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="relative w-16 h-16 mb-4">
                    <Image
                      src={testimonial.avatar || "/placeholder.svg"}
                      alt={testimonial.author}
                      fill
                      className="rounded-full object-cover"
                    />
                  </div>
                  <p className="mb-4 italic">"{testimonial.content}"</p>
                  <div>
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}


export default function QuoteSection() {
  return (
    <section className="py-16 bg-[#1a3a3a] text-white">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <p className="text-xl md:text-2xl font-serif italic">"Verily, with hardship comes ease."</p>
          <p className="mt-4 text-[#8a6e4b]">Quran 94:6</p>
        </div>
      </div>
    </section>
  )
}


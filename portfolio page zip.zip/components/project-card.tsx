import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ExternalLink } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface ProjectCardProps {
  title: string
  description: string
  content: string
  image: string
}

export default function ProjectCard({ title, description, content, image }: ProjectCardProps) {
  return (
    <Card className="overflow-hidden border-none shadow-md">
      <div className="relative aspect-video">
        <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <CardHeader>
        <CardTitle className="font-serif text-[#1a3a3a]">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-[#1a3a3a]/70">{content}</p>
      </CardContent>
      <CardFooter>
        <Button className="bg-[#1a3a3a] hover:bg-[#1a3a3a]/90 text-white w-full" size="sm" asChild>
          <Link href="#" className="flex items-center gap-1">
            <ExternalLink className="h-4 w-4" />
            View Project
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}


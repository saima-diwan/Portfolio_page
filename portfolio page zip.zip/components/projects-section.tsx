import ProjectCard from "./project-card"

export default function ProjectsSection() {
  const projects = [
    {
      title: "Contemporary Blue Qur'an Inspired Art",
      description: "Modern interpretation of the historic Blue Qur'an",
      content:
        "A series of contemporary artworks inspired by the magnificent 9th-10th century Blue Qur'an, reimagined for modern spaces.",
      image:
        "https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg",
    },
    {
      title: "Ceramic Collection with Calligraphy",
      description: "Inspired by historical Islamic pottery",
      content:
        "A collection of ceramic pieces featuring Arabic calligraphy, drawing inspiration from 10th century bowls with Arabic inscriptions.",
      image:
        "https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg",
    },
    {
      title: "Textile Design with Kufic Script",
      description: "Modern fabrics with historical influences",
      content:
        "Contemporary textile designs inspired by historical Tiraz fragments, featuring elegant calligraphy for modern fashion and home decor.",
      image:
        "https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg",
    },
  ]

  return (
    <section id="projects" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-[#1a3a3a]">Contemporary Projects</h2>
          <p className="text-[#1a3a3a]/70 max-w-2xl mx-auto mt-4">
            Modern works inspired by the rich tradition of Islamic calligraphy and art from throughout history
          </p>
          <div className="w-24 h-1 bg-[#8a6e4b] mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <ProjectCard
              key={project.title}
              title={project.title}
              description={project.description}
              content={project.content}
              image={project.image}
            />
          ))}
        </div>
      </div>
    </section>
  )
}


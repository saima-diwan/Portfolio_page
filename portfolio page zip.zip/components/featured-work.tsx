import Image from "next/image"

export default function FeaturedWork() {
  return (
    <section className="py-16 bg-[#1a3a3a]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-white">Historical Inspirations</h2>
          <p className="text-white/70 mt-4 max-w-2xl mx-auto">
            Drawing inspiration from the rich tradition of Islamic calligraphy throughout history
          </p>
          <div className="w-24 h-1 bg-[#8a6e4b] mx-auto mt-4"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="group relative aspect-[3/4] overflow-hidden rounded-lg">
            <Image
              src="https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg"
              alt="Folio from the Blue Qur'an"
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1a3a3a]/80 to-transparent opacity-100 group-hover:opacity-90 transition-opacity duration-300 flex flex-col justify-end p-6">
              <h3 className="text-xl font-serif text-white">Folio from the "Blue Qur'an"</h3>
              <p className="text-white/80 text-sm mt-2">second half 9th-mid-10th century</p>
            </div>
          </div>
          <div className="group relative aspect-[3/4] overflow-hidden rounded-lg">
            <Image
              src="https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg"
              alt="Tiraz Textile Fragment"
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1a3a3a]/80 to-transparent opacity-100 group-hover:opacity-90 transition-opacity duration-300 flex flex-col justify-end p-6">
              <h3 className="text-xl font-serif text-white">Tiraz Textile Fragment</h3>
              <p className="text-white/80 text-sm mt-2">late 9th-early 10th century</p>
            </div>
          </div>
          <div className="group relative aspect-[3/4] overflow-hidden rounded-lg">
            <Image
              src="https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg"
              alt="Bowl with Arabic Inscription"
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1a3a3a]/80 to-transparent opacity-100 group-hover:opacity-90 transition-opacity duration-300 flex flex-col justify-end p-6">
              <h3 className="text-xl font-serif text-white">Bowl with Arabic Inscription</h3>
              <p className="text-white/80 text-sm mt-2">10th century</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}


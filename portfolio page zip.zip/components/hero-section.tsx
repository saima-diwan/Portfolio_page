import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

export default function HeroSection() {
  return (
    <section id="about" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 -z-10 opacity-5">
        <Image
          src="https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg"
          alt="Islamic calligraphy background"
          fill
          className="object-cover"
        />
      </div>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-[#1a3a3a]">
              Islamic Design & Calligraphy
            </h1>
            <h2 className="text-xl md:text-2xl text-[#8a6e4b] font-serif">Blending tradition with modern aesthetics</h2>
            <p className="text-lg text-[#1a3a3a]/80 max-w-md">
              Creating beautiful Islamic art, calligraphy, and design solutions that honor tradition while embracing
              contemporary sensibilities.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-[#1a3a3a] hover:bg-[#1a3a3a]/90 text-white" asChild>
                <Link href="#projects">View Portfolio</Link>
              </Button>
              <Button variant="outline" className="border-[#8a6e4b] text-[#8a6e4b] hover:bg-[#8a6e4b]/10" asChild>
                <Link href="#contact">Request a Commission</Link>
              </Button>
            </div>
          </div>
          <div className="relative aspect-square w-full max-w-md mx-auto">
            <Image
              src="https://sjc.microlink.io/Olk78ohLNfdxVb3I5cevuVHlZS-Ri7d_wMk8xiWFiectF7jaixrfezlFBsZj-hAHBc8MIYGHCwS_3RXjAG9vfA.jpeg"
              alt="Islamic Calligraphy Collection"
              fill
              className="object-contain rounded-lg shadow-lg"
              priority
            />
          </div>
        </div>
      </div>
    </section>
  )
}


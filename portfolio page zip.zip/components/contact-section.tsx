import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone } from "lucide-react"

export default function ContactSection() {
  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-[#1a3a3a]">Get In Touch</h2>
            <p className="text-[#1a3a3a]/70 max-w-2xl mx-auto mt-4">
              Interested in commissioning a piece or discussing a project? Reach out to start the conversation.
            </p>
            <div className="w-24 h-1 bg-[#8a6e4b] mx-auto mt-4"></div>
          </div>

          <Card className="border-none shadow-lg overflow-hidden">
            <CardContent className="p-6">
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-[#1a3a3a]">
                      Name
                    </label>
                    <Input
                      id="name"
                      placeholder="Your name"
                      className="border-[#1a3a3a]/20 focus:border-[#8a6e4b] focus:ring-[#8a6e4b]"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-[#1a3a3a]">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Your email"
                      className="border-[#1a3a3a]/20 focus:border-[#8a6e4b] focus:ring-[#8a6e4b]"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium text-[#1a3a3a]">
                    Subject
                  </label>
                  <Input
                    id="subject"
                    placeholder="What's this about?"
                    className="border-[#1a3a3a]/20 focus:border-[#8a6e4b] focus:ring-[#8a6e4b]"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium text-[#1a3a3a]">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    placeholder="Your message"
                    rows={5}
                    className="border-[#1a3a3a]/20 focus:border-[#8a6e4b] focus:ring-[#8a6e4b]"
                  />
                </div>
                <Button type="submit" className="w-full bg-[#1a3a3a] hover:bg-[#1a3a3a]/90 text-white">
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center">
              <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-[#1a3a3a]/10">
                <Mail className="h-5 w-5 text-[#1a3a3a]" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-[#1a3a3a]">Email</h3>
                <p className="text-[#1a3a3a]/70">contact@noordesigns.com</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-[#1a3a3a]/10">
                <Phone className="h-5 w-5 text-[#1a3a3a]" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-[#1a3a3a]">Phone</h3>
                <p className="text-[#1a3a3a]/70">+1 (555) 123-4567</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}


export default function SkillsSection() {
  return (
    <section id="skills" className="py-16 bg-secondary/50">
      <div className="container">
        <h2 className="text-2xl font-bold text-center mb-8">My Skills</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[
            "React",
            "Next.js",
            "TypeScript",
            "Tailwind CSS",
            "Node.js",
            "UI/UX Design",
            "Responsive Design",
            "RESTful APIs",
            "GraphQL",
            "Git",
            "Figma",
            "Vercel",
          ].map((skill) => (
            <div
              key={skill}
              className="bg-white rounded-lg p-4 text-center shadow-sm hover:shadow-md transition-shadow"
            >
              <span className="font-medium">{skill}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}


import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-[#1a3a3a] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-serif text-xl font-bold mb-4">Noor Designs</h3>
            <p className="text-white/70">
              Creating beautiful Islamic art and design solutions that honor tradition while embracing contemporary
              aesthetics.
            </p>
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#about" className="text-white/70 hover:text-[#8a6e4b] transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link href="#projects" className="text-white/70 hover:text-[#8a6e4b] transition-colors">
                  Projects
                </Link>
              </li>
              <li>
                <Link href="#services" className="text-white/70 hover:text-[#8a6e4b] transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-white/70 hover:text-[#8a6e4b] transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold mb-4">Newsletter</h3>
            <p className="text-white/70 mb-4">
              Subscribe to receive updates on new projects and Islamic design inspiration.
            </p>
            <div className="flex">
              <Input
                placeholder="Your email"
                className="rounded-r-none border-white/20 bg-white/10 text-white placeholder:text-white/50"
              />
              <Button className="rounded-l-none bg-[#8a6e4b] hover:bg-[#8a6e4b]/90">Subscribe</Button>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10 mt-8 pt-8 text-center text-white/50">
          <p>© {new Date().getFullYear()} Noor Designs. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}


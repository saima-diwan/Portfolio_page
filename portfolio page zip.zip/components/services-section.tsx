import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-[#f0ede3]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-[#1a3a3a]">Services</h2>
          <p className="text-[#1a3a3a]/70 max-w-2xl mx-auto mt-4">
            Professional Islamic design and calligraphy services for various needs and projects.
          </p>
          <div className="w-24 h-1 bg-[#8a6e4b] mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="bg-white border-none shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="font-serif text-[#1a3a3a]">Custom Calligraphy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#1a3a3a]/70">
                Bespoke Arabic and Islamic calligraphy for personal gifts, home decor, or commercial use.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-[#1a3a3a]/70">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Quranic verses and hadiths</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Names and phrases</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Digital and physical formats</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-white border-none shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="font-serif text-[#1a3a3a]">Islamic Interior Design</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#1a3a3a]/70">
                Design services for mosques, prayer spaces, and Islamic-inspired interiors.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-[#1a3a3a]/70">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Mosque and prayer room design</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Islamic-inspired home interiors</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Geometric pattern applications</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-white border-none shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="font-serif text-[#1a3a3a]">Digital Islamic Design</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#1a3a3a]/70">
                Modern digital design services with Islamic aesthetics for various applications.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-[#1a3a3a]/70">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Islamic app and website UI/UX</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Islamic educational materials</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Social media content for Islamic brands</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}


import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AboutCalligraphy() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-serif font-bold text-[#1a3a3a] text-center">
            The Significance of Calligraphy in Islamic Art
          </h2>
          <div className="w-24 h-1 bg-[#8a6e4b] mx-auto my-6"></div>

          <div className="prose prose-lg max-w-none text-[#1a3a3a]/80">
            <p>
              Calligraphy holds a special place in Islamic art and culture. As the Metropolitan Museum of Art notes,
              "Objects from different periods and regions vary in the use of calligraphy in their overall design,
              demonstrating the creative possibilities of calligraphy as ornament."
            </p>

            <p>
              The art of beautiful writing, or calligraphy, has long been the most esteemed form of art in Islam because
              of its association with the Qur'an, the Muslim holy book. The Qur'an was transmitted orally for several
              decades before being written down in the mid-seventh century A.D.
            </p>

            <p>
              The development of calligraphy as an art form has been strongly influenced by the Qur'an and its
              transcription, illumination, and binding. The emphasis placed on writing extended from the Qur'an to all
              types of works including scientific treatises, poetry, and stories.
            </p>

            <p>
              Various calligraphic styles developed over time, including Kufic, Naskh, Thuluth, Diwani, and many others.
              Each style has its own characteristics and was used for different purposes throughout Islamic history.
            </p>

            <p>
              At Noor Designs, we draw inspiration from these rich historical traditions while creating contemporary
              works that speak to modern sensibilities. Our designs honor the sacred tradition of Islamic calligraphy
              while exploring new applications and contexts.
            </p>
          </div>

          <div className="mt-8 flex justify-center">
            <Button className="bg-[#1a3a3a] hover:bg-[#1a3a3a]/90 text-white" asChild>
              <Link href="#projects">Explore Our Calligraphy Projects</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

